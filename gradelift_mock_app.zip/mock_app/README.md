# Gradelift Upper Limb Mock Exam

60 questions, 50 minutes, no login, unlimited retakes. Questions come from a Google Sheet through Streamlit Secrets, so the answers never sit in the public repo.

## Setup (once)
1. Upload `Gradelift_Mock_Exam_Questions.xlsx` to Google Drive and open it as a Google Sheet. Keep the tab names unchanged.
2. Google Cloud console: create a project, enable the Google Sheets API, create a Service Account, add a JSON key.
3. Share the Google Sheet with the service account's `client_email` (Viewer is enough, the app only reads).
4. Push this folder to GitHub. `.gitignore` keeps secrets out.
5. share.streamlit.io: New app, pick the repo, main file `app.py`. In Advanced settings > Secrets, paste `.streamlit/secrets.toml.example` filled with your real values (`sheet_id` is the long ID in the Sheet's URL).
6. Check tab says READY, then share the app link.

## Notes
- The timer is 50 minutes (Settings tab, cell B4). The exam auto-submits at zero.
- Refreshing the page restarts the exam. Warn students not to refresh.
- Question edits show up within about 10 minutes.
- Local test without Google: `MOCK_LOCAL_XLSX=file.xlsx streamlit run app.py`
